Die Siedler von Catan


Projekt Programmieren

DHBW Stuttgart Campus Horb

Artem Mordan, Marcel Vollmer, Julian Riegraf


Dozenten: Michael Uhl, Martin Pl�micke



SiedlerVonCatan.jar ist die geforderte ausf�hrbare Datei. 
Zum spielen einfach die zip-Datei entpacken und loslegen, eine aktuelle Java Version (min. 8.0_73) ist Vorraussetzung.

Viel Spass beim Spielen.